

<div class="global-navbar bg-white header-area header-sticky wow slideInDown sticky-top">
    <div class="container">
        <div class="row">
        <?php
            $setting = App\Models\Settings::find(1);
        ?>

        <?php if($setting): ?>
            <div class="col-md-3 d-none d-sm-none d-md-inline">
                <img src="<?php echo e(asset('Image/setting/'.$setting->logo)); ?>"  width="150px" height="80px" alt="logo">
            </div>
        <?php endif; ?>

            <div class="col-md-9 my-auto">
                <div class="border text-center  p-2">
                    <h5>  advestire here</h5>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- ***** Preloader Start ***** -->
<div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
        <span class="dot">D</span>
        <div class="dots">
        <span> S</span>
        <span>A</span>
        <span>I</span>
        </div>
    </div>
    </div>
    <!-- ***** Preloader End ***** -->

    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky wow slideInDown sticky-top" data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="container">
        <div class="row">
        <div class="col-12">
            <nav class="main-nav">

                <?php
                $setting = App\Models\Settings::find(1);
            ?>

            <?php if($setting): ?>

            <!-- ***** Logo Start ***** -->
            <a href="<?php echo e(route('frontend')); ?>" class="logo d-none d-sm-none d-md-inline">
                <img src="<?php echo e(asset('Image/setting/'.$setting->logo)); ?>"  width="150px" height="80px" alt="logo">
            </a>

            <?php endif; ?>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav d-none d-lg-block">
                <li class="scroll-to-section"><a href="<?php echo e(route('frontend')); ?>" class="active">Home</a></li>
                <?php
                $categories = App\Models\Category::where('navbar_status','0')->where('status','0')->get();
                ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cateitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="scroll-to-section">
                        <a href="<?php echo e(url('tutorial/'.$cateitem->slug)); ?>"><?php echo e($cateitem->name); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <li class="scroll-to-section"><a href="#services">Services</a></li>
                <li class="scroll-to-section"><div class="main-red-button-hover"><a href="<?php echo e(route('contact')); ?>">Contact Us Now</a></div></li>
     <!--           <li>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">Logout</a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>    -->
            </ul>
            <a class='menu-trigger'>
                <span>Menu</span>
            </a>
            <!-- ***** Menu End ***** -->
            </nav>



        </div>
        </div>
    </div>
    </header>
    <!-- ***** Header Area End ***** -->


<?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/layouts/inc/frontend-navbar.blade.php ENDPATH**/ ?>