<?php $__env->startSection('title','Edit Video'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card mt-4">
        <div class="card-header">
             <h4 class="">Edit Video</h4>
        </div>
        <div class="card-body">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('update_video',$video->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label> Post Name :</label>
                    <input type="text" name="name" value="<?php echo e($video->name); ?>" class="form-control">
                </div>


                <div class="mb-3">
                    <label> yt Iframe :</label>
                    <input type="text" value="<?php echo e($video->yt_iframe); ?> " name="yt_iframe" class="form-control">
                </div>

                <div class="mb-3">
                    <label> Image :</label>
                    <input type="file" name="image" class="form-control">
                </div>

                <div class="mb-3">
                    <label> Description :</label>
                    <textarea name="description"    rows="2" class="form-control"><?php echo $video->description; ?> </textarea>
                </div>



                <div class="row">

                    <div class="col-md-3 mb-3">
                        <label> Status :</label>
                        <input type="checkbox" name="status" <?php echo e($video->status =='1' ? 'checked' : ''); ?>  >
                    </div>

                    <div class="col-md-6">
                        <button type="submit" class="btn btn-primary float-end"> Update Video </button>
                    </div>

                </div>



            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/admin/videos/edit.blade.php ENDPATH**/ ?>