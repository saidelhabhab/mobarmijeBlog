<?php $__env->startSection('title','Edit user'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card mt-4">
        <div class="card">
            <div class="card-header">
                <h4>Edit  Users  <a href="<?php echo e(route('users')); ?>" class="btn btn-danger float-end">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>



                    <div class="mb-3">
                        <label> Full Name :</label>
                        <p class="form-control"><?php echo e($user->name); ?> </p>

                    </div>

                    <div class="mb-3">
                        <label> Email :</label>
                        <p class="form-control"><?php echo e($user->email); ?> </p>

                    </div>

                    <div class="mb-3">
                        <label> Create at :</label>
                        <p class="form-control"><?php echo e($user->created_at->format('d/m/Y')); ?> </p>

                    </div>

                <form action="<?php echo e(route('update_user',$user->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label> Role as :</label>
                            <select name="role_as" id="" class="form-control">
                                <option value="1"<?php echo e($user->role_as == '1' ? 'selected' : ''); ?>>Admin</option>
                                <option value="0"<?php echo e($user->role_as == '0' ? 'selected' : ''); ?>>User</option>
                                <option value="2"<?php echo e($user->role_as == '2' ? 'selected' : ''); ?>>Blogger</option>

                            </select>
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary float-end"> Update role  </button>
                        </div>

                </form>

            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>