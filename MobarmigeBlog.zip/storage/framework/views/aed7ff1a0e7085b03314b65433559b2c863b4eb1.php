<?php $__env->startSection('title',"$setting->meta_title"); ?>
<?php $__env->startSection('meta_description',"$setting->description"); ?>
<?php $__env->startSection('meta_keyword',"$setting->meta_keyword"); ?>
<?php $__env->startSection('content'); ?>



<div class="bg py-5" style="background-color: #e6f2ff">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="swiffy-slider slider-item-show2 slider-item-reveal slider-nav-outside slider-nav-round slider-nav-visible slider-indicators-outside slider-indicators-round slider-indicators-dark slider-nav-animation slider-nav-animation-fadein" bis_skin_checked="1">
                    <ul class="slider-container py-4">
                        <?php $__currentLoopData = $all_Post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemAll_Post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <li class="slide-visible">
                            <div class="card shadow h-100" bis_skin_checked="1">
                                <div class="ratio ratio-16x9" bis_skin_checked="1">
                                    <img src="<?php echo e(asset('Image/post/'.$itemAll_Post->image)); ?>" class="card-img-top" loading="lazy" alt="...">
                                </div>
                                <div class="card-body p-3 p-xl-5" bis_skin_checked="1">
                                    <h3 class="card-title h5"><?php echo e($itemAll_Post->name); ?></h3>
                                    <p class="card-text"> <?php echo e(strip_tags(substr($itemAll_Post->description,0,350))); ?></p>
                                    <div bis_skin_checked="1">
                                        <a href="<?php echo e(url('tutorial/'.$itemAll_Post->category->slug.'/'.$itemAll_Post->slug)); ?>" class="btn btn-primary float-end">Show more </a>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <button type="button" class="slider-nav" aria-label="Go left"></button>
                    <button type="button" class="slider-nav slider-nav-next" aria-label="Go left"></button>

                    <div class="slider-indicators" bis_skin_checked="1">
                        <button class="" aria-label="Go to slide"></button>
                        <button aria-label="Go to slide" class="active"></button>
                        <button aria-label="Go to slide"></button>
                        <button aria-label="Go to slide"></button>
                        <button aria-label="Go to slide"></button>
                    </div>
                </div>


            </div>

        </div>
    </div>
</div>


<div class="py-1 bg-secondary">
    <div class="container">
        <div class="text-center p-3">
            <h3> ads here</h3>
        </div>
    </div>
</div>

<div class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4> Said ELHABHAB</h4>
                <div class="underline">
                </div>
                    <p> Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum praesentium iusto nesciunt dolores obcaecati culpa dolore quae quaerat, tempora itaque laborum tenetur? Aut voluptatem voluptate, natus earum culpa quasi fugit.
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum praesentium iusto nesciunt dolores obcaecati culpa dolore quae quaerat, tempora itaque laborum tenetur? Aut voluptatem voluptate, natus earum culpa quasi fugit.
                    </p>
            </div>
        </div>
    </div>
</div>

<div class="py-4 bg-secondary">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4> all Category </h4>
                <div class="underline">
                </div>
            </div>

                <?php $__currentLoopData = $all_Catogory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_CatogoryItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="card mb-3">
                        <div class="card-body">
                            <a href="<?php echo e(url('tutorial/'.$all_CatogoryItem->slug)); ?>" class="text-decoration-none">
                                <h4 class="text-dark -mb-0"> <?php echo e($all_CatogoryItem->name); ?></h4>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>

<div class="py-5 bg-white">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4> last Post </h4>
                <div class="underline">
                </div>
            </div>
            <div class="col-md-8">
                <?php $__currentLoopData = $all_Post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_PostItem2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card mb-3 bg-gray shadow">
                        <div class="card-body">
                            <a href="<?php echo e(url('tutorial/'.$all_PostItem2->category->slug.'/'.$all_PostItem2->slug)); ?>" class="text-decoration-none">
                                <h4 class="text-dark -mb-0"> <?php echo e($all_PostItem2->name); ?></h4>
                            </a>
                            <h6> Post on : <?php echo e($all_PostItem2->created_at->format('d-m-Y')); ?>

                            </h6>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-4">
                <div class="border text-center p-3">
                    <h4> ads</h4>
                </div>
            </div>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravelProjects\MobarmigeBlog - Copy\resources\views/frontend/index.blade.php ENDPATH**/ ?>