<?php $__env->startSection('title',"$category->meta_title"); ?>
<?php $__env->startSection('meta_description',"$category->meta_description"); ?>
<?php $__env->startSection('meta_keyword',"$category->meta_keyword"); ?>

<?php $__env->startSection('content'); ?>
<div class="py-5" >
    <div class="container" style="padding-top: 90px">
        <div class="row">
            <div class="col-md-9">
                <div class="category-heading">
                    <h4> <?php echo e($category->name); ?></h4>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


                <div class="card card-shadow mt-4">
                    <div class="card-body">
                        <a href="<?php echo e(url('tutorial/'.$category->slug.'/'.$postitem->slug)); ?>" class="text-decoration-none"><h2 class="post-heading"><?php echo e($postitem->name); ?></h2>
                        </a>
                        <h6> Post on : <?php echo e($postitem->created_at->format('d-m-Y')); ?>

                            <span class="ms-3"> Create by: <?php echo e($postitem->user->name); ?></span>
                        </h6>

                    </div>

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <div class="card card-shadow mt-4">
                    <div class="card-body">
                        <h1> no post availble</h1>
                    </div>
                </div>

                <?php endif; ?>

                <div class="your-paginate mt-4">
                    <?php echo e($post->links()); ?>

                </div>

            </div>
            <div class="col-md-3">
                <div class="border p-2">
                    <h4> Advertising area</h4>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/frontend/post/index.blade.php ENDPATH**/ ?>