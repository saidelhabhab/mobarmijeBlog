<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>">
    <meta name="keyword" content="<?php echo $__env->yieldContent('meta_keyword'); ?>">
    <meta name="author" content="Said ELHABHAB">

    <?php
     $setting = App\Models\Settings::find(1);

    ?>

    <?php if($setting): ?>
    <!-- Favicons -->
    <link href="<?php echo e(asset('Image/setting/'.$setting->favicon)); ?>" rel="shortcut icon" type="image/x-icon">
    <?php endif; ?>


    <link href="https://cdn.jsdelivr.net/npm/swiffy-slider@1.6.0/dist/css/swiffy-slider.min.css" rel="stylesheet" crossorigin="anonymous">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/styles.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet" />





</head>
<body>
    <div id="app">
        <?php echo $__env->make('layouts.inc.frontend-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('layouts.inc.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>" </script>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('assets/js/scripts.js')); ?>" ></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/swiffy-slider@1.6.0/dist/js/swiffy-slider.min.js" crossorigin="anonymous" defer></script>

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\laravelProjects\MobarmigeBlog - Copy\resources\views/layouts/app.blade.php ENDPATH**/ ?>