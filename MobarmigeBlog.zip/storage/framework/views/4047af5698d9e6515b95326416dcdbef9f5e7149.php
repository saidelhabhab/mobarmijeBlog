<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?php echo e(asset('loginpublic/images/icons/favicon.ico')); ?>"/>
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/vendor/bootstrap/css/bootstrap.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/fonts/font-awesome-4.7.0/css/font-awesome.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/fonts/Linearicons-Free-v1.0.0/icon-font.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/vendor/animate/animate.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/vendor/css-hamburgers/hamburgers.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/vendor/select2/select2.min.css')); ?>">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/css/util.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('loginpublic/css/main.css')); ?>">
<!--===============================================================================================-->
</head>
<body>



    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 p-l-50 p-r-50 p-t-77 p-b-30">

                <?php if(session('message')): ?>
                <div class="alert alert-warning mb-3 mt-4">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>

                <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                    <span class="login100-form-title p-b-55">
                        <?php echo e(__('Login')); ?>

                    </span>

                    <div class="wrap-input100 validate-input m-b-16 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-validate="Valid email is required: ex@abc.xyz" >
                        <input id="email" type="email" class="input100 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <span class="lnr lnr-envelope"></span>
                        </span>

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div class="wrap-input100 validate-input m-b-16" data-validate = "Password is required">

                        <input id="password" type="password" class="input100 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <span class="lnr lnr-lock"></span>
                        </span>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="contact100-form-checkbox m-l-4">

                            <input class="input-checkbox100" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                            <label class="label-checkbox100" for="remember">
                                <?php echo e(__('Remember Me')); ?>

                            </label>

                    </div>

                    <div class="container-login100-form-btn p-t-25">
                        <button class="login100-form-btn">
                            <?php echo e(__('Login')); ?>

                        </button>
                    </div>

                    <?php if(Route::has('password.request')): ?>
                    <a class="btn btn-link text-decoration-none" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot Your Password?')); ?>

                    </a>
                    <?php endif; ?>

                    <div class="text-center w-full p-t-42 p-b-22">
                        <span class="txt1">
                            Or login with
                        </span>
                    </div>

                    <a href="#" class="btn-face m-b-10 text-decoration-none">
                        <i class="fa fa-facebook-official"></i>
                        Facebook
                    </a>

                    <a href="<?php echo e(route('googlelogin')); ?>" class="btn-google m-b-10 text-decoration-none">
                        <img src="<?php echo e(asset('loginpublic/images/icons/icon-google.png')); ?>" alt="GOOGLE">

                        Google
                    </a>

                    <a href="#" class="btn-face m-b-10 text-decoration-none">
                        <i class="fa fa-twitter-square" aria-hidden="true"></i>
                        Twitter
                    </a>

                    <a href="<?php echo e(route('githublogin')); ?>" class="btn-google m-b-10 text-decoration-none">
                        <i class="fa fa-github-square" aria-hidden="true"> Github</i>


                    </a>


                    <div class="text-center w-full p-t-115">
                        <span class="txt1">
                            Not a member?
                        </span>

                        <a class="txt1 bo1 hov1" href="<?php echo e(route('register')); ?>">
                            Sign up now
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>




<!--===============================================================================================-->
    <script src="<?php echo e(asset('loginpublic/vendor/jquery/jquery-3.2.1.min.js')); ?>"></script>
<!--===============================================================================================-->
    <script src="<?php echo e(asset('loginpublic/vendor/bootstrap/js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('loginpublic/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
<!--===============================================================================================-->
    <script src="<?php echo e(asset('loginpublic/vendor/select2/select2.min.js')); ?>"></script>
<!--===============================================================================================-->
    <script src="<?php echo e(asset('loginpublic/js/main.js')); ?>"></script>

</body>
</html>


<?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/auth/login.blade.php ENDPATH**/ ?>