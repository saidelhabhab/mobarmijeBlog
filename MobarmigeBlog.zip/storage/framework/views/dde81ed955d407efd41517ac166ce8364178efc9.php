<?php $__env->startSection('title','Add Post'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card mt-4">
        <div class="card">
            <div class="card-header">
                <h4>Add Video
                    <a href="<?php echo e(route('add-video')); ?>" class="btn btn-primary float-end"> Add Video</a>
                </h4>
            </div>
            <div class="card-body">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
                <form action="<?php echo e(url('admin/add-video')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>



                    <div class="mb-3">
                        <label> Video Name :</label>
                        <input type="text" name="name" class="form-control">
                    </div>


                    <div class="mb-3">
                        <label> Youtube Iframe Link :</label>
                        <input type="text" name="yt_iframe" class="form-control">
                    </div>


                    <div class="mb-3">
                        <label> Image :</label>
                        <input type="file" name="image" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label> Description :</label>
                        <textarea name="description"   rows="2" class="form-control"></textarea>
                    </div>



                    <h6> Status Mode </h6>
                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label> Status :</label>
                            <input type="checkbox" name="status" >
                        </div>

                        <div class="col-md-3">
                            <button type="submit" class="btn btn-primary float-end"> Save Video </button>
                        </div>

                    </div>



                </form>
            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/admin/videos/create.blade.php ENDPATH**/ ?>