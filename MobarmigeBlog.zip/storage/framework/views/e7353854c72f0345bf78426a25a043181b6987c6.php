
<div class="py-5 bg-dark text-white">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="underline" > </div>
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eos maiores ullam fuga quisquam minima culpa porro adipisci veritatis, ab quam nobis atque et dolore similique cumque ipsa eius aliquam necessitatibus?
                </p>
            </div>
            <div class="col-md-3">
                <h5>Quick link</h5>
                <div class="underline" > </div>
                <div> <a href="" class="text-white"> Home</a></div>
                <div> <a href="" class="text-white"> About us</a></div>
                <div> <a href="" class="text-white"> Contact us</a></div>
                <div> <a href="" class="text-white"> Need Promotion ?</a></div>
            </div>
            <div class="col-md-3">
                <h5>Follow us On </h5>
                <div class="underline" > </div>
                <div> <a href="" class="text-white"> Facebook <i class="fa fa-facebook-official" aria-hidden="true"></i></a></div>
                <div> <a href="" class="text-white"> Twitter <i class="fa fa-twitter" aria-hidden="true"></i></a></div>
                <div> <a href="" class="text-white"> Instagram<i class="fa fa-instagram" aria-hidden="true"></i></a></div>
                <div> <a href="" class="text-white"> Youtube <i class="fa fa-youtube" aria-hidden="true"></i></a></div>
            </div>
        </div>

    </div>
</div>

<div class="py-2 bg-light">
    <div class="container text-center">
        <p class="mb-0 ">
            &copy; Copyright at <a href="#" class="text-decoration-none"> Said ELHABHAB </a>
            All right reserved.
            Designed and Developed by Said ELHABHAB <?php echo e(date('Y')); ?>


        </p>
    </div>
</div>
<?php /**PATH E:\laravelProjects\MobarmigeBlog - Copy\resources\views/layouts/inc/frontend-footer.blade.php ENDPATH**/ ?>