<?php $__env->startSection('title','Videos'); ?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <div class="card mt-4">
        <div class="card">
            <div class="card-header">
                <h4>View Videos
                    <a href="<?php echo e(route('add-video')); ?>" class="btn btn-primary float-end"> Add Video</a>
                </h4>
            </div>
            <div class="card-body">
                <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table  id="myTable" class="table table-bordred">
                        <thead>
                            <tr>
                                <th> ID </th>
                                <th> Post Name </th>
                                <th>  Image </th>
                                <th> Description </th>
                                <th> Status </th>
                                <th> Edit </th>
                                <th> Delete </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videotitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($videotitem-> id); ?></td>
                                <td><?php echo e($videotitem->name); ?></td>
                                <td><img src="<?php echo e(asset('Image/videos/'.$videotitem->image)); ?>" width="50px" height="50px" alt=""></td>
                                <td><?php echo e($videotitem->description); ?></td>
                                <td><?php echo e($videotitem-> status == '1' ?'Hidden' : 'Show'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('edit_video',$videotitem-> id)); ?>" class="btn btn-success"> Edit</a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('delete_video',$videotitem-> id)); ?>" class="btn btn-danger"> Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                    </table>
                </div>

            </div>

        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravelProjects\MobarmigeBlog\resources\views/admin/videos/index.blade.php ENDPATH**/ ?>