<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contact us</title>
</head>
<body>
    <h1>{{ $datalis['name'] }}</h1>
    <h2>{{ $datalis['email'] }}</h2>
    <h2>{{ $datalis['message'] }}</h2>
    <p>Thank You to contact us</p>
</body>
</html>
